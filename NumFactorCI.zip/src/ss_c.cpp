#include <random>
#include <random>
#include <algorithm>
#include <iterator>
#include <iostream>
#include <vector>
#include <cmath>
#include <stdio.h>
#include <RcppArmadillo.h>
//[[Rcpp::depends(RcppArmadillo)]]

#include <math.h>

using namespace Rcpp;

//[[Rcpp::export]]
NumericMatrix scale_c (NumericMatrix submat, int n_0, int p_0)
{
	NumericVector mu(p_0);
	NumericVector sd(p_0);

	for(int j=0; j < p_0; j++){
		for(int i=0; i < n_0; i ++){
			mu(j) = mu(j) + submat(i,j);
		}
	}		

	for(int j=0; j < p_0; j++){
		for(int i=0; i < n_0; i ++){
			sd(j) = sd(j) + pow(submat(i,j) - mu(j), 2.0);
		}
		sd(j) = sd(j)/(n_0 - 1);
		sd(j) = pow(sd(j), 0.5);
	}			
	
	for(int j=0; j < p_0; j++){
		for(int i=0; i < n_0; i ++){
			submat(i,j) = (submat(i,j) - mu(j));	
		}
	}	
	
	return submat;
}

//[[Rcpp::export]]
NumericMatrix subsample_matrix(NumericMatrix mat, IntegerVector row, IntegerVector col, int n_0, int p_0, int i) 
{
	
	NumericMatrix tmp(n_0, p_0);
		
	for(int l = 0; l < n_0; l++){
		int ll = i*n_0 + l;
		for(int k =0; k < p_0; k++){
			
			int kk = i*p_0 + k;
			tmp(l,k) =mat(row(ll), col(kk));
		}
	}
	
	//tmp = scale_c(tmp, n_0, p_0);

return tmp;
}

//[[Rcpp::export]]
NumericMatrix emp_ci_fn(NumericMatrix sing_val_mod, int n_iter_mod, int n_0, int p_0, double alpha){
	
	NumericVector mu(p_0);
	NumericVector sd(p_0);
	NumericMatrix emp_ci(2,p_0);
	double alp0, alp1;
	
	alp0 = (1-alpha)/2;
	alp1 = alpha + (1-alpha)/2;
		
	double z0 = R::qnorm(alp0, 0, 1,1,0);
	double z1 = R::qnorm(alp1, 0, 1,1,0);

	for(int j =0; j < p_0; j++){
		for(int i =0; i < n_iter_mod; i++){
			mu(j) = mu(j) + sing_val_mod(i,j)/n_iter_mod;	
		}
	}
	
	for(int j=0; j < p_0; j++ ){
		for(int i =0; i < n_iter_mod; i++){
			sd(j) = sd(j) + pow( sing_val_mod(i,j) - mu(j), 2.0)/n_iter_mod;
		}		
	}	
	
	for(int j=0; j < p_0; j++ ){	
		emp_ci(0,j) = mu(j) + z0*pow(sd(j), 0.5);
		emp_ci(1,j) = mu(j) + z1*pow(sd(j), 0.5);		
	}
	
return emp_ci;	

}

//[[Rcpp::export]]
NumericVector singular(NumericMatrix mat, IntegerVector row, IntegerVector col, int n_0, int p_0, int i) 
{
	NumericVector sval(p_0);
	arma::mat mperm(n_0,p_0);
	NumericMatrix mat_perm(n_0, p_0);
	
	mat_perm = subsample_matrix(mat, row, col, n_0, p_0, i );
	mperm = as<arma::mat>(mat_perm);
	mperm = mperm.t()*mperm/n_0;
			
	arma::mat U, V;
	arma::vec s;
	arma::svd(U, s, V, mperm);
	sval = wrap(s);

return sval;	
}

//[[Rcpp::export]]
NumericMatrix cMeans(NumericMatrix spike_mat, int alpha_len, int n_sub, int n_perm ){
	
	NumericMatrix mean_hist(alpha_len, n_perm);
	
	for(int l =0 ; l < n_sub ; l++){
		for(int s=0; s< alpha_len; s++){
			int ss = l*alpha_len + s;
			for(int k =0; k < n_perm ; k++){
				mean_hist(s,k) = mean_hist(s,k) + spike_mat(ss,k)/n_sub;	
			}
		}
	}

return mean_hist;	
}


//[[Rcpp::export]]
NumericMatrix optim_c(NumericMatrix mat, int N, int p, int n_0, int p_0, int n_iter, int alpha_len, int n_sub, int n_perm, IntegerMatrix index_row, IntegerMatrix index_col, NumericVector alpha_vec, double eps){ 
	
	bool    status   ;
	double  alpha    ;
	int     spike=0  ;
	int     pless1 = p_0 - 1;
	int 	n_iter_mod = n_iter-1;
			
	NumericMatrix sing_val(n_iter,p_0);
	NumericMatrix sing_val_mod(n_iter_mod, p_0);
	NumericVector sval(p_0);
	
	IntegerMatrix col(p, n_perm);
	IntegerMatrix row(N, n_perm);
	
	NumericMatrix spike_mat(alpha_len*n_sub, n_perm);
	NumericMatrix mean_hist(alpha_len,n_perm);
	NumericMatrix emp_ci(2,p_0);

	for(int j =0; j < n_sub ; j++){
			
		int  start_ind = n_perm*j ;
		int  end_ind   = n_perm*(j+1) -1; 
			
		row = index_row( _ , Range(start_ind, end_ind) );
		col = index_col( _ , Range(start_ind, end_ind) );
			
			for(int k=0; k < n_perm; k++){
				
				IntegerVector row_vec  = row(_, k);
				IntegerVector col_vec  = col(_, k);

			
				for(int i=0; i < n_iter; i++ ){

					int  start_ind = n_iter*i ;
					int  end_ind   = n_iter*(i+1) -1; 
				
					if(i==0){	

						sval = singular(mat, row_vec, col_vec, n_0, p_0, i);
						
						}else{
					
						int ii = i -1;
						sing_val_mod(ii, _) = singular(mat, row_vec, col_vec, n_0, p_0, i);
					}			
				}	
				
				for(int s=0; s < alpha_len; s++){	
					
					alpha = alpha_vec[s];
					emp_ci = emp_ci_fn(sing_val_mod,  n_iter_mod, n_0, p_0, alpha);
								
					for(int ind = 0 ; ind < p_0; ind++){
			
						status = (( emp_ci(0,ind) - sval(ind) < -eps ) & (emp_ci(1,ind) - sval(ind) > eps)) ;
						
						if(  (status == 0) |(ind == pless1) ){
							spike = ind; 
							break;
						}
					}
					
					int ss  = alpha_len*j + s;
					spike_mat(ss,k) =	spike ;	
				}
			}
	}

	mean_hist = cMeans(spike_mat,alpha_len, n_sub, n_perm); 

return mean_hist;

}