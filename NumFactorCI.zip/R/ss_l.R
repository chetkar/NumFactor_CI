#####################################################
#Computes Confidence Intervals of Number of Factors
#Depends on functions in C
#Uses Normality Test
#####################################################
#wkdir <- "C:\\Users\\HAL9000\\Desktop\\ServerRun\\PA_C"
#setwd(wkdir)

library(stats)
library(mvtnorm)
library(pracma)
library(RMTstat)
library(Rcpp)
library(RcppArmadillo)



ob.compute <- function(x,u){
	
	mu <- u
	
	if( sd(x) < 0.01){
		
		sd.null <- 10^{-50}
		ans     <- mean( (abs(x-mu)^3) )/(sd.null)^3 
		
		}else{
		
			ans <- mean( (abs(x-mu)^3) )/(sd(x))^3 
	}
	
	ans
}

tsquant <- function(mu, std, alpha){

 beta1 <- alpha + (1-alpha)/2
 beta0 <- (1-alpha)/2
 
 ci <- cbind(mu + std*qnorm(beta1), mu + std*qnorm(beta0))

ci
}

#Generates Data Matrix
gen_mat <- function(N, p, r, load_mean =rep(6,r), opt_errdist= "norm", opt_mod = "FA", scale.error = 1){
	
	lam_mat   <- matrix(rnorm(N*r,0,1), N, r)	
	#id_mat   <- diag(runif(p, 1, 5),p, p)
	id_mat    <- scale.error*diag(runif(p, 1, 1),p, p)
    
	if(opt_errdist == "norm"){
		noise_mat <- rmvnorm(N, rep(0,p) , id_mat)
	}else if( opt_errdist =="t"){
		noise_mat <- rmvt(N, df=2, sigma= diag(p), delta=rep(0,p) , type="shifted")	
	}
	
	if( opt_mod == "FA"){
		
		if(r== 0){

				x        <- noise_mat%*%id_mat
				
		}else{
			
			if(r==1 ){
				load_mat <- matrix(rnorm(p*r,0, 1),r, p)
				load_mat <- load_mat/sqrt( sum(load_mat^2))
		
				load_mat <- load_mean*load_mat
				x        <- lam_mat %*%load_mat + noise_mat%*%id_mat
		
			}else{
	
				load_mat       <- matrix(0,r, p)
				diag(load_mat) <- rep(1, r, 1)
				r_dum          <- r + 1
				load_mat[,r_dum : p] <- 1
	
				orth_mat <- orth(load_mat)
				col_ind  <- rep(NA, p)
				col_ind[1:r] <- seq(1,r,1)
				p_rem        <- p -r
				r_dum        <- r+ 1
				col_ind[r_dum:p] <- sample( seq(1,r,1),p_rem, replace=TRUE)
				load_mat         <- orth_mat[,col_ind] 
				load_mat <- diag(load_mean)%*%load_mat
				x        <- lam_mat %*%load_mat + noise_mat%*%id_mat
			}
		}	
	
	}else{
		
		if(r == 0){
		
			x        <- noise_mat%*%id_mat
		
		}else{
		
			if(r==1 ){
				load_mat       <- matrix(0,r, p)
				diag(load_mat) <- rep(1,r) 
				col_ind  <- rep(NA, p)
				col_ind[1:r] <- seq(1,r,1)
				p_rem        <- p -r
				r_dum        <- r+ 1
				col_ind[r_dum:p] <- sample( seq(1,r,1),p_rem, replace=TRUE)
				load_mat         <- load_mat[,col_ind] 
		
				load_mat <- load_mean*load_mat
				x        <- lam_mat %*%load_mat + noise_mat%*%id_mat
		
			}else{
	
				load_mat       <- matrix(0,r, p)
				diag(load_mat) <- rep(1,r)

				col_ind  <- rep(NA, p)
				col_ind[1:r] <- seq(1,r,1)
				p_rem        <- p -r
				r_dum        <- r+ 1
				col_ind[r_dum:p] <- sample( seq(1,r,1),p_rem, replace=TRUE)
				load_mat         <- load_mat[,col_ind] 
			
				load_mat <- diag(load_mean)%*%load_mat
				x        <- lam_mat %*%load_mat + noise_mat%*%id_mat
			}
		}		
	
	}

	x
}

#Computes log likelihood
loglik <- function(r, mat, gam){
	
	v <- r
	s <- floor(r)
	N <- nrow(mat)

	eig  <- eigen( t(mat)%*%mat/N)$values
	ss   <- s + 1	
	tau_vec <- eig[min(s,1):s]

	loglik       <- dtw(eig[ss], beta=1, log=TRUE)
	
loglik	
}

#Computes log likelihood
estu <- function(mat, gam){
	
	eps <- 10^-5
	N   <- max(nrow(mat),ncol(mat))

	eig    <- eigen( t(mat)%*%mat/N)$values
	eig    <- (svd(mat/sqrt(N))$d)^2
	
	loglik <- dtw(eig, beta=1, log=TRUE)
	
	index   <- which(loglik > - Inf)[1]
	
	if( length(index) > 0 ){
		out     <- index - 1
	}else{
		out <- 100
	}
	
out
}

outu <- function(mat){
		
		p         <- ncol(mat)
		pless1    <- p -1
		sval_full <- rep(NA, pless1)
		dum.val2  <- dum.val1 <- rep(NA, pless1)

		sval_full <- svd(mat)$d
		dum.val1  <- sval_full[1:pless1]
		dum.val2  <- sval_full[2:p]
		dum.val2  <- as.vector(dum.val1)/as.vector(dum.val2)
		u         <- which(dum.val2 == max(dum.val2))
u
}

index_permute <- function(N, p, n_sub, n_perm, rat){

	n_0 <- floor(N/rat)
	p_0 <- floor(p/rat)
	
	index_row <- matrix(NA, N, n_sub*n_perm)
	index_col <- matrix(NA, p, n_sub*n_perm)
	
	out      <- list()
	
	#Counter of n_sub*n_perm columns
	id_count <- 0 
		
	for(j in 1:n_sub){
	
		comp_row <- seq(1,N,1)
		comp_col <-	seq(1,p,1)
		
		sub_row <- sample( length(comp_row), n_0)
		sub_col <- sample( length(comp_col), p_0)
		
		row_reset <- comp_row <- setdiff(comp_row, sub_row)
		col_reset <- comp_col <- setdiff(comp_col, sub_col)
	
		for(k in 1:n_perm){
					
			id_count                   <- id_count + 1	
			index_row[1:n_0, id_count] <- sub_row
			index_col[1:p_0, id_count] <- sub_col
		
				
			NN <- N - n_0
			pp <- p - p_0

			ind_row  <- comp_row[sample(length(comp_row),NN)]
			ind_col  <- comp_col[sample(length(comp_col),pp)]
				
			row_s_ind <- n_0 + 1
			col_s_ind <- p_0 + 1

			index_row[row_s_ind : N, id_count] <- ind_row
			index_col[col_s_ind : p, id_count] <- ind_col
			
		}
	}
	
	out[[1]] <- index_row
	out[[2]] <- index_col

out
}


#Steps
#1_Generates random sample indices
#2_Call C++ function to compute SVD & estimate

optim_r <- function(mat, n_sub.vec, n_perm.vec, eps_vec=c(0.02), u){

	sc_summ  <- matrix(NA, length(n_sub.vec), 3)
	sc.vec   <- rep(NA, length(n_sub.vec))
	
	for(sc in 1:length(n_sub.vec)){
	
		n_sub  <- n_sub.vec[sc]
		n_perm <- n_perm.vec[sc]

		sourceCpp("ss_c.cpp")
		#sourceCpp("ss_normal_c.cpp")

		out_ind <- list()
	
		N   <- nrow(mat)
		p   <- ncol(mat)	
		gam <- p/N
	
		rat  <- N^(1/3)	
		n_0  <- floor(N/rat)
		p_0  <- floor(p/rat)


		n_0 <- floor(N/rat)
		p_0 <- floor(p/rat)
		
		n.iter   <- floor(N/n_0) -1
		sing.val <- matrix(NA, n.iter, p_0)
	

		n_iter   <- floor(N/n_0) -1
		sing_val <- matrix(NA, n_iter, p_0)

		out_ind  <- index_permute(N, p, n_sub = n_sub, n_perm = n_perm, rat)

		index_row <- matrix(out_ind[[1]], N)
		index_row <- index_row -1

		index_col <- matrix(out_ind[[2]], p)
		index_col <- index_col -1

		alpha_vec = seq(0.501, 0.99, 0.01)
		alpha_len = length(alpha_vec)

		ob        = rep(NA, length(alpha_len))
		ob.mat    = matrix(NA, length(eps_vec), 40)
		rf_mat    = matrix(NA, length(eps_vec), 40)
		sdf_mat   = matrix(NA, length(eps_vec), 40)
		alpha_mat = matrix(NA, length(eps_vec), 40)
		
		obc      <- rep(NA, 40)
		obc.mat  <- matrix(NA, length(eps_vec), 40)
		ob.vec   <- rep(NA, length(eps_vec))
		
		check <- rep(NA, 39)
		
		for(i in 1:length(eps_vec)){
	
			eps = eps_vec[i]

			#sourceCpp("ss_c.cpp")
			#Calling C++ function	 
			spike_mat = optim_c(mat, N, p, n_0, p_0, n_iter, alpha_len, n_sub, n_perm, index_row, index_col, alpha_vec, eps)	

			r_vec <- sd_vec <- s_vec <- rep(NA, alpha_len)
			r_mat <- matrix(NA, alpha_len , n_perm)
			r_mat <- spike_mat
	
			r_vec	  = rowMeans(r_mat)

			for(l in 1:alpha_len){
	
				sd_vec[l] = sd(r_mat[l,])
			}
	
			
			for(l in 1:alpha_len){
				ob[l] = dt( (r_vec[l] - u - 1)/sd_vec[l], df=1, ncp=0, log = TRUE)
			}
		
			opt_ind    = which(ob == max(ob))[1]
			alpha      = alpha_vec[opt_ind]
	
			next_ind   = (opt_ind + 1)
	
			if( next_ind <= alpha_len){
				next_alpha = alpha_vec[next_ind]
				
				}else{
					next_alpha = min(alpha_vec[alpha_len] + 0.005, 1)
			}	
			
			last_ind   = opt_ind  - 1

			if(last_ind==0){
						
				last_alpha = 0.50001
			}else{
						
				last_alpha = alpha_vec[last_ind]
			}
			
			bin_width   <- (next_alpha - last_alpha)/40
			init_alpha  <- last_alpha + bin_width
			alphaf_grid <- seq(init_alpha, next_alpha, bin_width)
			alphaf_len  <- length(alphaf_grid)
	
			spike_matf = optim_c(mat, N, p, n_0, p_0, n_iter, alphaf_len, n_sub, n_perm, index_row, index_col, alphaf_grid, eps)
		
			obf <- rf_vec   <- sdf_vec <- sf_vec <- rep(NA, alphaf_len)	
	
			rf_vec   = rowMeans(spike_matf)

			for(l in 1:alphaf_len){
				sdf_vec[l] = sd(spike_matf[l,])
			}

			for(l in 1:alphaf_len){
				obf[l] = dt( (rf_vec[l] - u - 1 )/sdf_vec[l], df=1, ncp=0, log = TRUE)
			}
	
			obc    <- obf
					
			}
			
			alpha <- alphaf_grid[which(obc==max(obc))[1]]
		}
			

	alpha
}

pa_sub <- function(r, mat, n_sub=30, n_perm = 30, rat=10, alpha=alpha, eps){

	#sourceCpp("ss_c.cpp")

	out_ind <- list()
	
	N   <- nrow(mat)
	p   <- ncol(mat)	
	gam <- p/N
	
	
	rat  <- N^(1/3)	
	n_0  <- floor(N/rat)
	p_0  <- floor(p/rat)

	n_iter   <- floor(N/n_0) -1
	sing_val <- matrix(NA, n_iter, p_0)

	out_ind  <- index_permute(N, p, n_sub = n_sub, n_perm = n_perm, rat)
				
	index_row <- matrix(out_ind[[1]], N)
	index_row <- index_row -1

	index_col <- matrix(out_ind[[2]], p)
	index_col <- index_col -1

	alpha_vec = c(alpha)
	alpha_len = 1
	#Calling C++ function	 
	out = optim_c(mat, N, p, n_0, p_0, n_iter, alpha_len, n_sub, n_perm, index_row, index_col, alpha_vec, eps)	
	
out
}




########################################################
########################################################

  # library(foreach)
  # library(doParallel)
  # no_cores <- 6
  # cl       <- makeCluster(no_cores)
  # registerDoParallel(cl)

  # N.vec      <- rep(c(1000), each=6)
  # gam.vec    <- rep(c(0.2, 0.5, 0.8), each=2)
	
  # load.mean.list <- list(c(10,15), c(10, 14, 18, 22, 26, 30))

  # ans <- foreach( sc=1:length(N.vec),.combine=rbind)%dopar%
  # {
	# library(mvtnorm)
	# library(pracma)
	# library(gtools)
	# library(Rcpp)
	# library(RcppArmadillo)
	# library(RMTstat)
	# sourceCpp("ss_c.cpp")
	# unitcomp(sc)
	 
  # }	
	# stopCluster(cl)


getci <- function(mat, alpha){

	p <- ncol(mat)
	N <- nrow(mat)
	gam <- p/N

	n_sub  <- c(100)
	n_perm <- c(500)

	
	optim_out   <- optim_r(mat, n_sub =n_sub, n_perm = n_perm)
	alphaf      <- optim_out[1]
	eps         <- optim_out[2]

	m           <- 1
	r_rep       <- rep(r, m)
	pa_sub.out	<- lapply( r_rep, pa_sub, mat, n_sub= n_sub, n_perm = n_perm, rat=rat, alpha=alphaf, eps=eps)

	pa_sub_mat.out <- matrix(NA, n_perm, m)
	
	for(l in 1:m){
		pa_sub_mat.out[,l] <- pa_sub.out[[l]]
	}
	
	mu     <- mean(pa_sub_mat.out)
	std    <- sd(pa_sub_mat.out)
	
	alpha0 <- (1-alpha)/2
	alpha1 <- (1-alpha)/2 + alpha
	
	ci <- c( floor(tsquant(mu,std,alpha0)), floor(tsquant(mu,std,alpha1)))
	
ci	
}
